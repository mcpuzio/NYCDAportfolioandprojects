$(document).ready(
	function() {
		$("body").click(
		function(){
			$("#wrapper1").slideUp();

			$("h1").fadeIn(2000);
				});
		$("p").click(function(){
        $(this).hide();
    });

	});

	});